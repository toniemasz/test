import pytest
from sqlmodel import create_engine, Session, SQLModel
from backend.models.transfers import Transaction, TransactionType
from backend.services.balance_calculator import BalanceCalculator

@pytest.fixture(name="test_session")
def session_fixture():
    """Provides an isolated, in-memory SQLite database session for testing purposes."""
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)

    with Session(engine) as session:
        yield session

def test_get_balance_calculates_correctly(test_session):
    """Tests if the get_balance method correctly calculates the sum of mock transactions."""
    transfer1 = Transaction(account_id=99, amount=100.0, type=TransactionType.IN, title="Wypłata")
    transfer2 = Transaction(account_id=99, amount=30.0, type=TransactionType.OUT, title="Kino")

    test_session.add(transfer1)
    test_session.add(transfer2)
    test_session.commit()

    accountant = BalanceCalculator(test_session)
    balance = accountant.get_balance(account_id=99)

    assert balance == 70.0