from unittest.mock import MagicMock, patch
import pytest
from fastapi import HTTPException

from backend.services.transfer_service import TransferService


def test_execute_transfer_success():
    """
    Tests the successful execution of a transfer between two accounts.
    Verifies that a dual-entry (two transaction records) is created
    and committed to the database when conditions are met.
    """
    db = MagicMock()
    service = TransferService()

    # Mock receiver existence
    db.exec.return_value.first.return_value = MagicMock()

    with patch('backend.services.transfer_service.BalanceCalculator') as MockCalc:
        # Mock sufficient funds
        MockCalc.return_value.get_balance.return_value = 1000.0

        result = service.execute_transfer(
            db=db,
            from_account="user1",
            to_account="user2",
            amount=100.0,
            title="Dinner split"
        )

        assert result["status"] == "success"
        assert result["message"] == "Transfer successful"

    # Verify dual-entry accounting (IN and OUT transactions)
    assert db.add.call_count == 2

    # Verify the transaction was saved
    db.commit.assert_called_once()


def test_execute_transfer_insufficient_funds():
    """
    Tests transfer failure when the sender has insufficient funds.
    Verifies that an HTTP 400 exception is raised and no database
    changes are made or committed.
    """
    db = MagicMock()
    service = TransferService()

    with patch('backend.services.transfer_service.BalanceCalculator') as MockCalc:
        # Mock insufficient funds
        MockCalc.return_value.get_balance.return_value = 10.0

        with pytest.raises(HTTPException) as exc:
            service.execute_transfer(
                db=db,
                from_account="user1",
                to_account="user2",
                amount=500.0,
                title="Movie tickets"
            )

    assert exc.value.status_code == 400
    assert "Insufficient funds" in exc.value.detail

    # Verify no transactions were created or saved
    db.add.assert_not_called()
    db.commit.assert_not_called()


def test_execute_transfer_receiver_not_found():
    """
    Tests transfer failure when the receiving account does not exist.
    Verifies that an HTTP 404 exception is raised and no database
    changes are made or committed.
    """
    db = MagicMock()
    service = TransferService()

    # Mock receiver not found
    db.exec.return_value.first.return_value = None

    with patch('backend.services.transfer_service.BalanceCalculator') as MockCalc:
        # Mock sufficient funds
        MockCalc.return_value.get_balance.return_value = 1000.0

        with pytest.raises(HTTPException) as exc:
            service.execute_transfer(
                db=db,
                from_account="user1",
                to_account="wrong-id",
                amount=10.0,
                title="Coffee"
            )

    assert exc.value.status_code == 404
    assert "Account not found" in exc.value.detail

    # Verify no transactions were created or saved
    db.add.assert_not_called()
    db.commit.assert_not_called()