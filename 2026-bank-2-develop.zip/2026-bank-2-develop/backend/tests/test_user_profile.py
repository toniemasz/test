from pathlib import Path

import pytest
from sqlmodel import Session, SQLModel, create_engine

from backend.models.user import User
from backend.routers.profile import ProfileUpdateRequest, get_profile, update_profile
from backend.services.user_profile_service import UserProfileService


@pytest.fixture()
def db_session(tmp_path: Path):
    engine = create_engine(
        f"sqlite:///{tmp_path / 'test.db'}", connect_args={"check_same_thread": False}
    )
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        yield session


@pytest.fixture()
def user(db_session: Session):
    current_user = User(
        username="john.doe",
        email="john@example.com",
        hashed_password="hashed",
    )
    db_session.add(current_user)
    db_session.commit()
    db_session.refresh(current_user)
    return current_user


def test_get_profile_returns_none_when_missing(db_session: Session, user: User):
    service = UserProfileService(db_session)

    assert service.get_profile(user.id) is None


def test_create_profile_persists_contact_data(db_session: Session, user: User):
    service = UserProfileService(db_session)

    profile = service.create_profile(user.id, "Jan", "Kowalski", "+48123123123")

    assert profile.id is not None
    assert profile.user_id == user.id
    assert profile.first_name == "Jan"
    assert profile.last_name == "Kowalski"
    assert profile.phone == "+48123123123"
    assert service.get_profile(user.id) == profile


def test_update_profile_changes_existing_record(db_session: Session, user: User):
    service = UserProfileService(db_session)
    service.create_profile(user.id, "Jan", "Kowalski", "+48123123123")

    profile = service.update_profile(user.id, "Anna", "Nowak", "+48987654321")

    assert profile.first_name == "Anna"
    assert profile.last_name == "Nowak"
    assert profile.phone == "+48987654321"


def test_update_profile_creates_record_when_missing(db_session: Session, user: User):
    service = UserProfileService(db_session)

    profile = service.update_profile(user.id, "Anna", "Nowak", "+48987654321")

    assert profile.id is not None
    assert profile.user_id == user.id
    assert profile.first_name == "Anna"
    assert profile.last_name == "Nowak"
    assert profile.phone == "+48987654321"


def test_router_get_profile_creates_profile(db_session: Session, user: User):
    profile = get_profile(current_user=user, db=db_session)

    assert profile.id is not None
    assert profile.user_id == user.id
    assert profile.first_name is None
    assert profile.last_name is None
    assert profile.phone is None


def test_router_update_profile_uses_service(db_session: Session, user: User):
    request = ProfileUpdateRequest(
        first_name="Jan",
        last_name="Kowalski",
        phone="+48123123123",
    )

    profile = update_profile(request=request, current_user=user, db=db_session)

    assert profile.user_id == user.id
    assert profile.first_name == "Jan"
    assert profile.last_name == "Kowalski"
    assert profile.phone == "+48123123123"
