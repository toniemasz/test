import pytest
from sqlmodel import Session, create_engine, SQLModel, select, func
from sqlalchemy.pool import StaticPool
from backend.services.database_seeder import DatabaseSeeder
from backend.auth.service import AuthService
from backend.models.user import User
from backend.models.account import Account
from backend.models.transfers import Transaction

@pytest.fixture(name="session")
def session_fixture():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool
    )
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        yield session

def test_seeder_populates_all_tables(session: Session):
    auth_service = AuthService(session)
    seeder = DatabaseSeeder(session, auth_service)

    seeder.run()

    users = session.exec(select(User)).all()
    assert len(users) == 6

    accounts = session.exec(select(Account)).all()
    assert len(accounts) == 6

    transactions = session.exec(select(Transaction)).all()
    assert len(transactions) == 15

def test_seeder_is_idempotent(session: Session):
    auth_service = AuthService(session)
    seeder = DatabaseSeeder(session, auth_service)

    seeder.run()
    first_run_user_count = session.exec(select(func.count(User.id))).one()

    seeder.run()
    second_run_user_count = session.exec(select(func.count(User.id))).one()

    assert first_run_user_count == second_run_user_count
    assert first_run_user_count == 6

def test_account_numbers_are_formatted_correctly(session: Session):
    seeder = DatabaseSeeder(session, AuthService(session))

    acc_num = seeder._generate_account_number(1)

    assert acc_num.startswith("PL")
    assert len(acc_num) == 28
    assert acc_num == "PL00000000000000000000000001"