from sqlmodel import Session, select
from backend.models.transfers import Transaction, TransactionType

class BalanceCalculator:
    """Service responsible for calculating the current balance of a specific account."""

    def __init__(self, session: Session):
        """Initializes the BalanceCalculator with a database session."""
        self.session = session

    def get_balance(self, account_id: int) -> float:
        """Calculates the total balance for a given account.
            Sums up all 'IN' transactions and subtracts all 'OUT' transactions."""
        statement = select(Transaction).where(Transaction.account_id == account_id)
        transactions = self.session.exec(statement).all()
        balance = 0.0
        for transaction in transactions:
            if transaction.type == TransactionType.IN:
                balance += transaction.amount
            elif transaction.type == TransactionType.OUT:
                balance -= transaction.amount
        return balance

