"""Service for user profile management."""

from sqlmodel import Session, select

from backend.models.user_profile import UserProfile


class UserProfileService:
    """Handles fetching and persisting user profile contact data."""

    def __init__(self, db: Session):
        self.db = db

    def get_profile(self, user_id: int) -> UserProfile | None:
        """Return the profile for a user, if it exists."""
        statement = select(UserProfile).where(UserProfile.user_id == user_id)
        return self.db.exec(statement).first()

    def create_profile(
        self,
        user_id: int,
        first_name: str | None = None,
        last_name: str | None = None,
        phone: str | None = None,
    ) -> UserProfile:
        """Create a new profile for a user."""
        existing = self.get_profile(user_id)
        if existing is not None:
            raise ValueError("Profile already exists")

        profile = UserProfile(
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            phone=phone,
        )
        self.db.add(profile)
        self.db.commit()
        self.db.refresh(profile)
        return profile

    def update_profile(
        self,
        user_id: int,
        first_name: str | None = None,
        last_name: str | None = None,
        phone: str | None = None,
    ) -> UserProfile:
        """Update an existing profile or create one if missing."""
        profile = self.get_profile(user_id)
        if profile is None:
            profile = UserProfile(user_id=user_id)
            self.db.add(profile)

        profile.first_name = first_name
        profile.last_name = last_name
        profile.phone = phone
        self.db.commit()
        self.db.refresh(profile)
        return profile
