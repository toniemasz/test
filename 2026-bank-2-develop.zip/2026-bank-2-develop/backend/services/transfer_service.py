from typing import Union

from sqlmodel import Session, select
from fastapi import HTTPException
from datetime import datetime, timezone

from backend.models.transfers import Transaction, TransactionType
from backend.models.account import Account
from backend.services.balance_calculator import BalanceCalculator


class TransferService:
    def __init__(self, db: Session = None):
        """
        Initializes the TransferService.
        Args:
            db (Session, optional): Database session injected for compatibility
                                    with external runners like DatabaseSeeder.
        """
        self.db = db

    def execute_transfer(
            self,
            db: Session = None,
            from_account: Union[Account, int, str] = None,
            to_account: Union[Account, int, str] = None,
            amount: float = 0.0,
            title: str = ""
    ) -> dict:
        """
        Executes a dual-entry money transfer between two accounts.

        Validates sender's balance and receiver's existence before creating
        paired Transaction records (OUT for sender, IN for receiver).
        Supports both raw IDs and Account objects (e.g., from DatabaseSeeder).
        Args:
            db: Active database session.
            from_account: Sender's Account object or ID.
            to_account: Receiver's Account object or ID.
            amount: Transfer value (must be >= 0).
            title: Transaction description.
        Returns:
            dict: Status map (e.g., {"status": "success", ...}).
        Raises:
            HTTPException: 400 (Insufficient funds), 404 (Not found), or 500 (DB error).
        """
        current_db = db or self.db

        if not current_db:
            raise ValueError("Database session is missing!")

        try:
            # Extract IDs regardless of input type (ID or Account object)
            f_id = from_account.id if isinstance(from_account, Account) else from_account
            t_id = to_account.id if isinstance(to_account, Account) else to_account

            # Inject the session into the BalanceCalculator constructor
            calculator = BalanceCalculator(current_db)

            # get_balance now only requires the account ID (f_id)
            if calculator.get_balance(f_id) < amount:
                raise HTTPException(status_code=400, detail="Insufficient funds")

            if not current_db.exec(select(Account).where(Account.id == t_id)).first():
                raise HTTPException(status_code=404, detail="Account not found")

            # Create paired transactions
            current_db.add(Transaction(account_id=f_id, amount=amount, title=title, type=TransactionType.OUT))
            current_db.add(Transaction(account_id=t_id, amount=amount, title=title, type=TransactionType.IN))

            current_db.commit()
            return {"status": "success", "message": "Transfer successful"}

        except HTTPException:
            raise
        except Exception as e:
            current_db.rollback()
            raise HTTPException(status_code=500, detail=f"Internal server error: {e}")