from typing import List

from sqlmodel import Session, select

from backend.auth.service import AuthService
from backend.database import engine
from backend.models.account import Account
from backend.models.user import User
from backend.models.transfers import Transaction, TransactionType

class DatabaseSeeder:
    """
        Service class responsible for populating the database with initial development
        and testing data. It ensures the system has a consistent state for all developers.
    """
    def __init__(self, session: Session, auth_service: AuthService):
        self.session = session
        self.auth_service = auth_service

    def _generate_account_number(self,index: int) -> str:
        """Generate a deterministic account number for seeding."""
        base = str(index).zfill(26)
        return f"PL{base}"

    def _create_user_with_initial_funds(self, username: str, email: str, amount: float) -> Account:
        """
        Create a User, their primary Account, and an initial deposit transaction.

        :param username: Unique login name.
        :param email: Unique email address.
        :param amount: Initial balance to be credited via a Transaction record.
        :return: The created Account object.
        """

        user = User(
            username=username,
            email=email,
            hashed_password=self.auth_service.hash_password("password123")
        )
        self.session.add(user)
        self.session.commit()
        self.session.refresh(user)

        account = Account(
            user_id=user.id,
            account_number=self._generate_account_number(user.id)
        )
        self.session.add(account)
        self.session.commit()
        self.session.refresh(account)

        initial_deposit = Transaction(
            account_id= account.id,
            amount=amount,
            title="Initial Deposit",
            type=TransactionType.IN
        )
        self.session.add(initial_deposit)
        self.session.commit()

        return account

    def _seed_fixed_scenario(self, accounts: List[Account]):
        """
        Execute a predefined set of transfers to create a predictable transaction history.
        :param accounts: List of accounts created during the seeding process.
        """
        scenario = [
            (0, 1, 150.00, "Dinner split"),
            (1, 2, 45.99, "Movie tickets"),
            (2, 3, 500.00, "Monthly rent"),
            (3, 4, 25.00, "Coffee"),
            (4, 0, 100.00, "Gift"),
        ]

        for s_idx, r_idx, amount, title in scenario:
            sender = accounts[s_idx]
            receiver = accounts[r_idx]

            self.session.add(Transaction(
                account_id=sender.id,
                amount=-amount,
                title=title,
                type=TransactionType.OUT
            ))

            self.session.add(Transaction(
                account_id=receiver.id,
                amount=amount,
                title=title,
                type=TransactionType.IN
            ))

    def run(self):
        if self.session.exec(select(User)).first():
            print("Database already contains data. Skipping seeding...")
            return

        print("Starting database seeding process...")

        admin = User(
            username="admin",
            email="admin@bank.io",
            hashed_password=self.auth_service.hash_password("admin"),
            is_admin=True
        )
        self.session.add(admin)
        self.session.commit()

        self.session.add(Account(
            user_id=admin.id,
            account_number=self._generate_account_number(admin.id)
        ))

        user_list = [
            ("jan_kowalski", "jan@bank.io"),
            ("anna_nowak", "anna@bank.io"),
            ("mariusz_p", "mariusz@bank.io"),
            ("justyna_k", "justyna@bank.io"),
            ("bartosz_b", "bartosz@bank.io")
        ]

        created_accounts = []
        for name, email in user_list:
            acc = self._create_user_with_initial_funds(name, email, 2000.0)
            created_accounts.append(acc)

        self._seed_fixed_scenario(created_accounts)

        print("Seeding completed successfully.")

if __name__ == "__main__":
    from backend.database import engine, init_db
    init_db()
    with Session(engine) as session:
        auth_srv = AuthService(session)
        seeder = DatabaseSeeder(session, auth_srv)
        seeder.run()