"""Models package. Import all models here so they are registered with SQLModel."""

from backend.models.user import User
from backend.models.account import Account
from backend.models.user_profile import UserProfile

__all__ = ["User", "Account", "UserProfile"]
