# id, account_id, amount, title, type: IN/OUT, created_at
from typing import Optional
from datetime import datetime, timezone
from enum import Enum
from sqlmodel import SQLModel, Field

class TransactionType(str, Enum):
    """Defines the allowed transaction types"""
    IN = "IN"
    OUT = "OUT"

class Transaction(SQLModel, table=True):
    """Represents a single transaction in the banking system."""

    __tablename__ = "transactions"

    id: Optional[int] = Field(default=None, primary_key=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    amount: float
    title: str
    type: TransactionType
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))