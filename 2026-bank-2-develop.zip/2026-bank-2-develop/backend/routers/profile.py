"""Profile router - endpoints for user profile management."""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session

from backend.auth import get_current_user
from backend.database import get_db
from backend.models.user import User
from backend.services.user_profile_service import UserProfileService

router = APIRouter(prefix="/profile", tags=["Profile"])


class ProfileUpdateRequest(BaseModel):
    """Schema for updating user profile."""
    first_name: str | None = None
    last_name: str | None = None
    phone: str | None = None


@router.get("")
def get_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get current user's profile."""
    service = UserProfileService(db)
    profile = service.get_profile(current_user.id)
    if profile is None:
        profile = service.create_profile(current_user.id)
    return profile


@router.put("")
def update_profile(request: ProfileUpdateRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Update current user's profile."""
    service = UserProfileService(db)
    return service.update_profile(
        current_user.id,
        first_name=request.first_name,
        last_name=request.last_name,
        phone=request.phone,
    )
