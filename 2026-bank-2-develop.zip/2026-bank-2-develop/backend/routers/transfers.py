"""Transfers router - endpoints for internal and external transfers."""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session

from backend.auth import get_current_user
from backend.database import get_db
from backend.models.user import User
from backend.services.transfer_service import TransferService

router = APIRouter(prefix="/transfers", tags=["Transfers"])


class TransferRequest(BaseModel):
    """Schema for a transfer."""
    to_account_number: str
    amount: float
    title: str


@router.post("")
def make_transfer(request: TransferRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Execute an internal transfer between accounts."""
    # TODO: Implement using TransferService
    service = TransferService()
    return service.execute_transfer(
        db=db,
        from_account_id=str(current_user.id),
        to_account_id=request.to_account_number,
        amount=request.amount,
        title=request.title
    )


@router.post("/external")
def make_external_transfer(request: TransferRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Execute a transfer to an external account."""
    # TODO: Implement using ExternalTransferService
    raise HTTPException(status_code=501, detail="Not implemented - waiting for ExternalTransferService")
